<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TipePenjualanBiayaTambahan extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
            return [
                    'id' => $this->biaya_tambahan_id,
                    'nama' => $this->biayaTambahan->nama_biaya_tambahan,
                    'jumlah' => $this->biayaTambahan->jumlah,
            ];
    }
}
